# Study Games — restored and upgraded (Nov 22, 2026)

Site source: `index.html`. Upload JUST `index.html` to the root of your GitHub Pages `STUDYGAMES4FUN` repository, replacing the old one, and commit. This archive does NOT automatically change your live site.

## Changes in this edition
- Recovered the full previous single-file site and embedded existing key-in-door cinematic.
- Removed the "Play invite music" button. The red full-screen invitation now attempts to start the looping invite song automatically. Browsers (especially iPhone) may block unprompted sound until the Open Study Games button is tapped. This cannot be bypassed safely.
- On Open Study Games, fade invitation audio, play the existing key-in-door clip, then continue to the site and music.
- Keeps existing arcade, educational quizzes, challenges, leveling, privacy effects, emergency Google Classroom link, video library, browser tabs, creator channel, and donation/premium UI. The separate movie theater was already removed in this source.
- Music playlist includes MONTAGEM-RITMADA, Digger Funk, Shape of You Hardtekk, invite song, original soundtrack. Songs automatically advance until visitors leave.
- Adds Premium controls for manual song selection, previous/next, shuffle, repeat-one, and local audio file preview. They unlock on verified Premium (or clearly labeled temporary beta preview). Regular looping playback stays free.
- The original five invitation codes (5-year access) and original permanent owner code can now unlock games and music immediately on this browser with no setup. The optional private Cloudflare Worker + D1 backend remains the only way to enforce one-use codes globally.

## Important: audio files
The original site soundtrack and key-door cinematic are embedded in index.html. The other named songs are listed by file path, but audio is NOT included. Put only recordings you have permission to distribute in `music/` with these names:
- montage-ritmada.mp3
- digger-funk.mp3
- shape-of-you-hardtekk.mp3
- thank-you-invite.mp3

If an audio file is absent, the playlist will fall back to another available track. Opening the site on iPhone can be the first gesture that permits audible music.

## Enable *real* premium access (not just beta preview)
1. Create a Cloudflare account and set up Workers and a D1 database (requires deployment by the owner).
2. `cd premium-worker` then run `npx wrangler d1 create study-games-premium` and copy the returned database ID into `wrangler.toml` (copy the included `.example`).
3. Run `npx wrangler d1 execute study-games-premium --remote --file=schema.sql`.
4. Add Worker secrets `OWNER_CODE` and `INVITE_CODES_JSON` from the **SEPARATE** private codes file (DO NOT publish that file). Example: `npx wrangler secret put OWNER_CODE`; repeat for `INVITE_CODES_JSON`, pasting the JSON array.
5. Run `npx wrangler deploy` from `premium-worker`.
6. Set the deployed HTTPS Worker URL in the site's owner/server settings under Donations & Premium. This URL is public; the secrets remain private at Cloudflare.
7. Redeem the owner code or any valid invitation code from the site. Owner Premium will be reported as Permanent / Never Expires.

**Security caveat**: client-only HTML cannot protect private codes or paid membership. The Worker/D1 option is the real verification mechanism. No subscriptions or donation checkouts are connected; the 7-day trial/$20 per two months is a displayed plan, not active billing. Keep the PRIVATE codes file outside the GitHub repository. Membership is remembered in this browser.

### Website
https://tonyjkxeasterncapeprovince-bot.github.io/STUDYGAMES4FUN/

## Premium redemption fix — IMPORTANT
- The **same original six codes** from the previous chat are accepted. None of their values changed.
- Enter a code in **Donations & Premium → Redeem free Premium**, then press **Redeem code**. A recognized code displays **✅ Premium Enabled** and unlocks Premium games and music controls.
- Without setting up a Worker, redemption is **local browser access only**, remembered in that browser. LocalStorage and public front-end controls are not tamper-proof; invitation codes cannot be truly one-use globally in a static site. Clearing browser data can lose access.
- For securely enforcing single-use across all visitors and devices, deploy the included private Cloudflare Worker database, then configure the site to point to its HTTPS URL. Do not put the code strings or private codes TXT file into public GitHub.
- Upload the updated **index.html** and commit before changes appear on the live GitHub Pages website.

## Fix v3 — November 22, 2026
- All SIX ORIGINAL Premium access codes are unchanged. The same original owner code never expires.
- Redeeming an original code no longer depends on a stale/incorrect Premium API URL saved on the visitor's browser.
- Now displays **✅ Premium Enabled** on accepted codes, and a visible **Premium redemption fix v3** indicator under the redeem status.
- Includes browser-only SHA-256 fallback so a local downloaded HTML preview can redeem a code even if WebCrypto is unavailable.
- IMPORTANT: Browser-only code checks are not a secure global single-use or paid access mechanism. For real one-use access globally, deploy the private backend included in this package; local preview is not a substitute.
- To update the PUBLIC SITE, upload and commit the NEW `index.html` file to the root of the GitHub repository; simply downloading this file doesn't publish the change. If your browser keeps the old version, reload the page after GitHub Pages redeploys.
