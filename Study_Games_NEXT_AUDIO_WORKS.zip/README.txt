STUDY GAMES — NEXT SONG PLAYBACK FIX (iPHONE)

This version fixes the case where imported recordings appear in the song list, but Next changes the song name without playing audio.

KEY CHANGE: The Next and Previous buttons now call the browser's native audio.play() directly inside the user tap, unmute sound, and clear leftover zero-volume intro fades. It removes the WebAudio GainNode that could stay suspended on iOS.

INSTALL:
1. Replace the CURRENT GitHub index.html with this new index.html and commit.
2. Open your updated Study Games page in Safari, tap Open Study Games, and finish/skip the intro.
3. Redeem your EXISTING Premium access if needed; the owner code is unchanged.
4. Open music menu > choose BOTH MP4 screen recordings from your iPhone's Files app.
5. Tap Next — the OTHER recording should start with sound. Tap Next again to return to the first.
6. If the song title changes but sound still doesn't start, read the message below the playlist. Some recordings or iOS browsers require a tap on Play Music.

Only the music playback JavaScript was edited. Premium codes, red-screen song, games, and gorilla surprise have not changed.
The MP4 recordings are not bundled in the website file; they remain private to the visitor's browser. Don't publicly distribute copyrighted music without authorization.
