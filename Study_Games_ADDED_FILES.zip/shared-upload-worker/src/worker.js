/**
 * Study Games public music upload API (Cloudflare Worker + R2).
 * Owner-only song publishing; everyone can play the public library.
 * Only publish media that you are permitted to distribute.
 */
const MAX_SIZE = 90 * 1024 * 1024;
const INDEX_KEY = '_study_games_song_index.json';
const TYPES = new Map([
  ['.mp3', 'audio/mpeg'],
  ['.m4a', 'audio/mp4'],
  ['.wav', 'audio/wav'],
  ['.mp4', 'video/mp4'],
]);

function sendJson(obj, status = 200, headers = {}) {
  return new Response(JSON.stringify(obj), {status, headers: {'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers}});
}
function cors(request, env) {
  const from = request.headers.get('Origin');
  return from === env.ALLOWED_ORIGIN ? {
    'Access-Control-Allow-Origin': from,
    'Access-Control-Allow-Methods': 'GET, HEAD, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Authorization, Content-Type, X-Song-Name',
    'Access-Control-Max-Age': '86400',
    'Vary': 'Origin'
  } : {};
}
function cleanName(raw) {
  try { raw = decodeURIComponent(raw); } catch {}
  return String(raw).replace(/[\\/\x00-\x1f\x7f<>:"|?*]/g, '_').trim().slice(0, 100);
}
async function readIndex(bucket) {
  const obj = await bucket.get(INDEX_KEY);
  if (!obj) return [];
  try { const data = await obj.json(); return Array.isArray(data) ? data : []; }
  catch { return []; }
}
function reply(response, headers) {
  const h = new Headers(response.headers);
  for (const [k,v] of Object.entries(headers)) h.set(k,v);
  return new Response(response.body,{status:response.status,headers:h});
}
async function songResponse(request, env, id, headers) {
  if (!/^[0-9a-f-]{36}$/.test(id)) return sendJson({error:'Song not found'},404,headers);
  const index = await readIndex(env.SONG_BUCKET);
  const song = index.find(x=>x.id===id);
  if (!song) return sendJson({error:'Song not found'},404,headers);
  const key = 'songs/'+id+song.ext;
  const meta = await env.SONG_BUCKET.head(key);
  if (!meta) return sendJson({error:'Song not found'},404,headers);
  const h = {'Accept-Ranges':'bytes','Content-Type':song.type,'Cache-Control':'public, max-age=3600',...headers};
  if (request.method === 'HEAD') return new Response(null,{status:200,headers:{...h,'Content-Length':String(meta.size)}});
  const rangeString=request.headers.get('Range');
  if (rangeString) {
    const m = /^bytes=(\d+)-(\d*)$/.exec(rangeString.trim());
    if (!m) return new Response(null,{status:416,headers:{...h,'Content-Range':`bytes */${meta.size}`}});
    const start=Number(m[1]);
    const end=m[2]?Math.min(meta.size-1,Number(m[2])):meta.size-1;
    if (start>=meta.size || end<start) return new Response(null,{status:416,headers:{...h,'Content-Range':`bytes */${meta.size}`}});
    const len=end-start+1;
    const ranged=await env.SONG_BUCKET.get(key,{range:{offset:start,length:len}});
    if (!ranged) return sendJson({error:'Song unavailable'},404,headers);
    return new Response(ranged.body,{status:206,headers:{...h,'Content-Length':String(len),'Content-Range':`bytes ${start}-${end}/${meta.size}`}});
  }
  const obj=await env.SONG_BUCKET.get(key);
  if(!obj) return sendJson({error:'Song unavailable'},404,headers);
  return new Response(obj.body,{status:200,headers:{...h,'Content-Length':String(meta.size)}});
}
export default {
 async fetch(request, env) {
  const headers=cors(request,env);
  const url=new URL(request.url);
  const path=url.pathname.replace(/\/$/,'');
  if (request.method === 'OPTIONS') {
    return request.headers.get('Origin')===env.ALLOWED_ORIGIN ? new Response(null,{status:204,headers}) : sendJson({error:'Origin not allowed'},403);
  }
  if (!env.SONG_BUCKET) return sendJson({error:'R2 bucket not configured'},503,headers);
  if (path==='/songs' && request.method==='GET') {
   const all=await readIndex(env.SONG_BUCKET);
   return sendJson({songs:all.map(({id,title,type})=>({id,title,type}))},200,headers);
  }
  if (path.startsWith('/songs/') && (request.method==='GET'||request.method==='HEAD'))
   return songResponse(request,env,path.slice('/songs/'.length),headers);
  if(path==='/upload' && request.method==='POST') {
   if(request.headers.get('Origin')!==env.ALLOWED_ORIGIN) return sendJson({error:'Upload origin not allowed'},403,headers);
   if(!env.OWNER_UPLOAD_TOKEN || request.headers.get('Authorization')!==`Bearer ${env.OWNER_UPLOAD_TOKEN}`)
    return sendJson({error:'Invalid owner upload key'},401,headers);
   const original=cleanName(request.headers.get('X-Song-Name')||'');
   const ext=(original.match(/\.[^.]+$/)||[])[0]?.toLowerCase()||'';
   if (!TYPES.has(ext)) return sendJson({error:'Upload an MP3, M4A, WAV or MP4 song'},415,headers);
   const type=TYPES.get(ext);
   const contentType=(request.headers.get('Content-Type')||'').split(';')[0].toLowerCase();
   if(contentType!=='application/octet-stream' && contentType!==type && !(ext==='.m4a' && contentType==='audio/x-m4a')) return sendJson({error:'Media type does not match file extension'},415,headers);
   if(!request.body) return sendJson({error:'No file provided'},400,headers);
   const size=Number(request.headers.get('Content-Length'));
   if (!Number.isFinite(size)||size<=0||size>MAX_SIZE) return sendJson({error:'File must be less than 90 MB'},413,headers);
   const id=crypto.randomUUID();
   await env.SONG_BUCKET.put('songs/'+id+ext,request.body,{httpMetadata:{contentType:type}});
   const index=await readIndex(env.SONG_BUCKET);
   index.push({id,title:original.slice(0,-ext.length),type,ext,createdAt:new Date().toISOString()});
   await env.SONG_BUCKET.put(INDEX_KEY,JSON.stringify(index),{httpMetadata:{contentType:'application/json'}});
   return sendJson({ok:true,id,title:original.slice(0,-ext.length)},201,headers);
  }
  return sendJson({error:'Not found'},404,headers);
 }
};
