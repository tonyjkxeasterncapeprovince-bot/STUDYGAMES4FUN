STUDY GAMES — ADDED FILES + EVERYONE'S MUSIC (NOVEMBER 2026)
==============================================================

WHAT THE NEW VERSION DOES
- Adds a visible "Added Files" button to the Study Games home page and music menu.
- On an iPhone, opens the iOS Files picker so the owner can choose MP3, M4A, WAV, or MP4 files.
- Lets Premium/Owner users preview songs locally. This works without a music server.
- Adds an "Everyone's music" section where visitors can play public songs.
- Includes TWO ways to publish authorized songs for everyone:
  A) Static GitHub upload (no server): save public-playlist.json and upload audio to music/.
  B) Connected owner-only upload server (Cloudflare Worker + R2): owner uploads directly from the button.

IMPORTANT: Songs in the Files app are not uploaded to the website automatically.
Only upload audio you own or have permission to distribute. The browser's Files
picker itself cannot upload files to every visitor's phone.

QUICK INSTALL
1. Open the STUDYGAMES4FUN repository on GitHub.
2. Replace the root index.html with this index.html and Commit changes.
3. Also upload the "music/public-playlist.json" file to the music/ folder.
4. Open Study Games. Look for "Added Files" on the home screen.

WAY A — PUBLISH SONGS THROUGH GITHUB (NO BACKEND)
1. In Study Games, redeem the original Owner Premium code.
2. Tap "Added Files", select authorized audio files from the Files app.
3. Open the music menu (•••) > "Owner: publish songs for everyone".
4. Confirm you have permission to distribute the recordings.
5. Tap "Prepare public playlist for GitHub" to download public-playlist.json.
6. In the GitHub repository, upload each selected audio file to the music/ folder.
7. Replace music/public-playlist.json with the downloaded manifest and Commit.
8. Every visitor will now see the shared tracks in "Everyone's music".
   To add more later, use the app again, keeping your prior manifest on GitHub.
   Songs must be uploaded with the SAME filenames as the ones selected.

WAY B — PUBLISH DIRECTLY WITH THE BUTTON (PRIVATE SERVER REQUIRED)
You must complete this ONE-TIME server setup before the button can upload globally.
1. Set up Cloudflare Workers and R2 using an account authorized to use those services.
   Note: some accounts require billing or payment details.
2. Create an R2 bucket named study-games-public-music.
3. In the included shared-upload-worker folder, run:
     npm install -g wrangler
     wrangler login
     wrangler secret put OWNER_UPLOAD_TOKEN
     wrangler deploy
   For the secret, use a strong random password not used anywhere else.
   Never put the secret into GitHub or index.html.
4. Copy your Worker HTTPS URL and edit the single line in index.html:
     const PUBLIC_MUSIC_API_URL='';
   Replace '' with your Cloudflare Worker URL, e.g.
     const PUBLIC_MUSIC_API_URL='https://study-games-public-music.YOURNAME.workers.dev';
   Do NOT put the upload secret in this line.
5. Commit the updated index.html to GitHub again.
6. In Study Games: Owner Premium > Added Files > select authorized files >
   Owner: publish songs for everyone > check permission > enter owner upload key >
   Publish selected files for everyone.
7. Songs instantly appear in Everyone's music on refreshed browsers.

IF YOU GET AN ERROR
- "Owner upload server isn't connected": use Way A or set the Worker URL for Way B.
- "Invalid owner upload key": enter the secret used at wrangler secret put.
- "Upload origin not allowed": make sure ALLOWED_ORIGIN is your exact GitHub Pages origin.
- "File must be less than 90 MB": select a smaller MP3/M4A file you can legally publish.
- iPhone might need a tap to allow music playback.

SAFETY & EXISTING FEATURES
- Existing redeem codes, red-screen song, key-in-door intro, games, and gorilla surprise were not changed.
- Public upload endpoints reject requests without the separate private owner key.
- Never use your public Premium code as your private upload key.
- You must be authorized to share any audio with everyone; possession in Files is not a license.
