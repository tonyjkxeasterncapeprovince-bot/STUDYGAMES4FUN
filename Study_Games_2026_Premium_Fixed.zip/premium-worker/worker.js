// Study Games Premium code verification — Cloudflare Worker + D1 database.
// Keep OWNER_CODE and INVITE_CODES_JSON in Worker secrets, NEVER in index.html.
// No payment processing is implemented by this example.

const enc = new TextEncoder();
const asJSON = (data, status=200, headers={}) => new Response(JSON.stringify(data), {
  status, headers: {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...headers}
});
const codeFormat = /^SG-[A-Z0-9-]{12,60}$/;
function corsFor(request, env) {
  const origin=request.headers.get('Origin')||'';
  return origin === (env.ALLOWED_ORIGIN||'') ? {'Access-Control-Allow-Origin':origin,
   'Access-Control-Allow-Methods':'GET, POST, OPTIONS',
   'Access-Control-Allow-Headers':'Authorization, Content-Type','Vary':'Origin'}:{};
}
function hex(bytes){return Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');}
async function hash(value){return hex(new Uint8Array(await crypto.subtle.digest('SHA-256',enc.encode(value))));}
function makeToken(){const a=new Uint8Array(32);crypto.getRandomValues(a);return btoa(String.fromCharCode(...a)).replaceAll('+','-').replaceAll('/','_').replaceAll('=','');}
function safeEqual(a,b){if(typeof a!=='string'||typeof b!=='string')return false;
 let d=a.length^b.length;const n=Math.max(a.length,b.length);for(let i=0;i<n;i++)d|=(a.charCodeAt(i)||0)^(b.charCodeAt(i)||0);return d===0;}
function fiveYearsFromNow(){const d=new Date();d.setUTCFullYear(d.getUTCFullYear()+5);return d.getTime();}
export default {
 async fetch(request, env) {
  const cors=corsFor(request,env);
  if(request.method==='OPTIONS')return new Response(null,{status:204,headers:cors});
  const url=new URL(request.url);
  if(request.headers.get('Origin') && !cors['Access-Control-Allow-Origin'])return asJSON({error:'Origin not allowed'},403,cors);
  if(!env.DB)return asJSON({error:'Database not connected'},503,cors);
  try {
   if(url.pathname==='/status' && request.method==='GET') {
    const bearer=(request.headers.get('Authorization')||'').match(/^Bearer (\S+)$/i);
    if(!bearer)return asJSON({premium:false},401,cors);
    const hashed=await hash(bearer[1]);
    const row=await env.DB.prepare('SELECT kind, expires_at FROM entitlements WHERE token_hash=?1').bind(hashed).first();
    if(!row)return asJSON({premium:false},401,cors);
    const permanent=row.kind==='owner' && row.expires_at===null;
    if(!permanent && Number(row.expires_at)<=Date.now())return asJSON({premium:false},401,cors);
    return asJSON({premium:true,permanent,expiresAt:permanent?null:new Date(Number(row.expires_at)).toISOString()},200,cors);
   }
   if(url.pathname==='/redeem' && request.method==='POST') {
    let body;try{body=await request.json()}catch{return asJSON({error:'Invalid JSON'},400,cors)}
    const code=String(body.code||'').trim().toUpperCase();
    if(!codeFormat.test(code))return asJSON({error:'Invalid code'},400,cors);
    const owner=String(env.OWNER_CODE||'').toUpperCase();
    let invites=[];try{invites=JSON.parse(env.INVITE_CODES_JSON||'[]')}catch{}
    const isOwner=owner && safeEqual(code,owner);
    const isInvite=invites.some(c=>safeEqual(code,String(c||'').toUpperCase()));
    if(!isOwner&&!isInvite)return asJSON({error:'Code not recognized'},403,cors);
    // One-time visitor claim, enforced with the D1 UNIQUE PRIMARY KEY.
    if(!isOwner){
      const codeHash=await hash(code);
      const used=await env.DB.prepare('INSERT OR IGNORE INTO claimed_codes (code_hash, claimed_at) VALUES (?1, ?2)').bind(codeHash,Date.now()).run();
      if(used.meta?.changes!==1)return asJSON({error:'Invitation code already claimed'},409,cors);
    }
    const token=makeToken();
    const expiresAt=isOwner?null:fiveYearsFromNow();
    await env.DB.prepare('INSERT INTO entitlements (token_hash,kind,expires_at,created_at) VALUES (?1,?2,?3,?4)').bind(await hash(token),isOwner?'owner':'invite',expiresAt,Date.now()).run();
    return asJSON({token,premium:true,permanent:isOwner,expiresAt:expiresAt?new Date(expiresAt).toISOString():null},200,cors);
   }
   return asJSON({error:'Not found'},404,cors);
  } catch(e){return asJSON({error:'Service error'},500,cors)}
 }
};
