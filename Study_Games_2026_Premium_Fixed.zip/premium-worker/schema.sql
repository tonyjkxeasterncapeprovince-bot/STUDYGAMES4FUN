CREATE TABLE IF NOT EXISTS claimed_codes (code_hash TEXT PRIMARY KEY, claimed_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS entitlements (token_hash TEXT PRIMARY KEY, kind TEXT NOT NULL, expires_at INTEGER, created_at INTEGER NOT NULL);
