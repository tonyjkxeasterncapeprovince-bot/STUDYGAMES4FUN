STUDY GAMES — CUSTOM YOUTUBE MUSIC PLAYER

WHAT CHANGED
- The three-line (☰) navigation now has 'YouTube Music · Digger Funk + Shape of You'.
- The section features a custom dark music-player design, track cards, Next and Previous buttons, and a visible official YouTube embed.
- Digger Funk video ID: LwZ0IbDcIac
- Shape of You Hardtekk video ID: 1J01N9hv_GY
- The original optional Files recording players remain in a collapsed section below.
- Other Study Games features remain in the original website file.

HOW TO PUBLISH
1. Open your GitHub STUDYGAMES4FUN repository (STUDYGAMES4FUN).
2. Upload/replace the repository root index.html with the enclosed index.html.
3. Commit changes and allow GitHub Pages to publish.
4. Reload the website; if you see a cached version, refresh or reopen.
5. Tap the menu (☰) and choose 'YouTube Music · Digger Funk + Shape of You'.

IMPORTANT
Playback requires an internet connection and embedding permission from each video owner. If embedded playback is unavailable, the player includes a regular Watch on YouTube link. Some iPhones require tapping Play inside YouTube to start sound; no website code can reliably override this browser rule.
YouTube videos are streamed from the official player and are not downloaded or republished in this package.

VALIDATION
Buttons and iframe switching were tested in an isolated browser UI test, not on your live GitHub page or an iPhone. The entire modified HTML's inline JavaScript passed Node syntax checks.
