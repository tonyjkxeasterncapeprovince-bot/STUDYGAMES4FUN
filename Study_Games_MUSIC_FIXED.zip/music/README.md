# Study Games music folder

To add the song for the **main website** (after the key-in-door cutscene), upload an MP3 you have the rights to publish with this exact GitHub path:

    music/main-screen-song.mp3

To add the song on the **red invitation screen**, use:

    music/thank-you-invite.mp3

Optional playlist tracks use these exact filenames:

    music/montagem-ritmada.mp3
    music/digger-funk.mp3
    music/shape-of-you-hardtekk.mp3

Please share only audio you created or have permission/licensing to distribute on a public website. The original Study Games soundtrack is already included in index.html and works as a fallback.

An owner with Premium may also open the music control panel and select a recording or audio file for a browser-only preview. That local preview does not publish the file to GitHub or make it audible to other visitors.

On iOS and most browsers, sound cannot reliably autoplay until the user taps **Open Study Games**. After that gesture, music can continue through the site and loop.
