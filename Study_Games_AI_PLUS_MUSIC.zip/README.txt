STUDY GAMES: AUDIO PLAYBACK + STUDY ASSISTANT
=============================================

UPDATED WEBSITE
  index.html — Upload THIS file to GitHub as the root index.html. Commit to publish.

WHAT CHANGED
- Your red-screen song, gorilla surprise, Premium codes, games, and existing music remain intact.
- MP4 recordings selected from Files use a native video-backed audio player on iPhone.
- Next / Previous / Play selected use a direct play action; two imported recordings cycle together.
- A new Study Games Assistant opens using the 🤖 Study Helper button after Open Study Games.
- The assistant has built-in answers for site help, simple arithmetic, and some study basics.
- For genuine open-ended AI conversation, deploy the optional secure Worker.

TO PLAY YOUR TWO SCREEN RECORDINGS
1. Go to Study Games, press Open Study Games, and open the ••• music menu.
2. Activate Premium with your UNCHANGED original code.
3. Tap Add songs from Files; choose both MP4 recordings you sent in chat.
4. Tap Play selected, then Next and Previous.
5. If your iPhone reports unavailable audio, export an audio-only M4A you are authorized to use and select that instead.
6. Very large MP4s may fail to save for future visits due to iPhone storage quotas: reselect after reload.

WHY THE SONGS ARE NOT EMBEDDED HERE
Your recordings may contain commercial copyrighted music. Saving a song in Files or screen-recording it does not give permission to republish it to every website visitor. This package DOES NOT redistribute those recordings. It gives you playback from your own Files, within your browser. To serve songs publicly, upload audio only if you have rights to distribute it.

OPTIONAL REAL AI CHAT SERVER SETUP (Cloudflare Worker)
- The website's built-in helper works without a server.
- To enable true AI responses, create a Cloudflare Worker using optional-ai-worker.js.
- Store the OpenAI key as a Cloudflare SECRET named OPENAI_API_KEY. Never put it in the website index.html. Ask a parent/guardian to manage paid service billing/verification if needed.
- Deploy the Worker; in index.html find SG_PUBLIC_AI_URL and set it to the HTTPS Worker URL. Commit and publish.
- Or enter that URL inside the Assistant's owner settings for a preview on your own device.
- The Worker allows only the GitHub Pages origin; review your site domain if you change it.
- Important: the sample per-isolate rate limit is NOT robust global protection. Configure Cloudflare WAF/Rate Limiting and spending limits before exposing paid AI publicly.
- Messages entered in AI mode are sent to the server and API provider. Built-in mode keeps answers in the browser.

TESTING
- Code and website should be tested using a browser after hosting (GitHub Pages HTTPS).
- An iPhone Safari test is still needed; no local test can guarantee hardware playback.
