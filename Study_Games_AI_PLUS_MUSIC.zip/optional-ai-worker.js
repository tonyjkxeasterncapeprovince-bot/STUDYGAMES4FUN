// Study Games AI — Cloudflare Worker (optional, NOT deployed by this download)
// Add OPENAI_API_KEY as a *secret* in Cloudflare, never in public HTML.
// Set the allowed Origin to the real site below. Enable billing controls and rate limits.
const ALLOWED_ORIGIN = 'https://tonyjkxeasterncapeprovince-bot.github.io';
const rates=new Map(); // best-effort per Worker isolate, NOT a global production rate limit
function json(payload,status=200,origin=ALLOWED_ORIGIN){return new Response(JSON.stringify(payload),{status,headers:{'content-type':'application/json; charset=utf-8','access-control-allow-origin':origin,'access-control-allow-methods':'POST, OPTIONS','access-control-allow-headers':'content-type','vary':'Origin','cache-control':'no-store'}});}
export default {
 async fetch(request,env){
  const origin=request.headers.get('origin')||'';
  if(origin!==ALLOWED_ORIGIN)return json({error:'Origin not allowed'},403);
  if(request.method==='OPTIONS')return new Response(null,{status:204,headers:{'access-control-allow-origin':ALLOWED_ORIGIN,'access-control-allow-methods':'POST, OPTIONS','access-control-allow-headers':'content-type','vary':'Origin'}});
  if(request.method!=='POST')return json({error:'Use POST'},405);
  if(!env.OPENAI_API_KEY)return json({error:'AI server not configured'},503);
  const ip=request.headers.get('cf-connecting-ip')||'unknown';
  const now=Date.now();const old=rates.get(ip)||[];const fresh=old.filter(t=>now-t<60000);
  if(fresh.length>=6)return json({error:'Too many requests; try again later'},429);
  fresh.push(now);rates.set(ip,fresh);
  if(rates.size>3000){for(const [k,v] of rates){if(!v.length||now-v[v.length-1]>60000)rates.delete(k);}}
  let body;try{body=await request.json();}catch(e){return json({error:'Invalid JSON'},400);}
  const messages=Array.isArray(body.messages)?body.messages.slice(-8):[];
  if(!messages.length||messages.some(m=>!m||!['user','assistant'].includes(m.role)||typeof m.content!=='string'||m.content.length>500))return json({error:'Invalid message'},400);
  if(messages[messages.length-1].role!=='user')return json({error:'Last message must be from user'},400);
  const reqBody={model:env.OPENAI_MODEL||'gpt-5-mini',instructions:'You are the Study Games Assistant, a cheerful, clear, age-appropriate study and website helper. Assist with school subjects, math, and how to use Study Games. Be honest about uncertainty and capabilities, keep answers concise, protect privacy, and do not ask students for passwords, account codes, or personal information. Do not assist with unsafe or age-inappropriate activities.',input:messages,store:false,max_output_tokens:500};
  try{
   const res=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'authorization':'Bearer '+env.OPENAI_API_KEY,'content-type':'application/json'},body:JSON.stringify(reqBody)});
   if(!res.ok){return json({error:'Upstream AI error'},502);}
   const data=await res.json();
   const output=(data.output||[]).filter(o=>o.type==='message').flatMap(o=>o.content||[]).filter(c=>c.type==='output_text').map(c=>c.text||'').join('\n').trim();
   if(!output)return json({error:'Empty AI answer'},502);
   return json({reply:output.slice(0,3500)});
  }catch(e){return json({error:'AI request failed'},502);}
 }
};
