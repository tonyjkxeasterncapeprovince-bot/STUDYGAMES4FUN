STUDY GAMES — MULTIPLAYER ARCADE UPGRADE

This package updates the complete Study Games website (index.html) based on the latest working custom YouTube player version.

MULTIPLAYER GAMES
- Tic-Tac-Toe (free Arcade)
- Connect Four (free Arcade)
- Chess (Premium Games)
- Checkers (Premium Games)
- Reversi (Premium Games)

Choose one of three options when starting any of these games:
1. Play Together: two people use one phone or computer.
2. Play vs Bot: play against an automated opponent. Bot AI is basic for Chess, Checkers and Reversi; stronger at Tic-Tac-Toe and simple Connect Four tactics.
3. Generate Room Code: keep your game open and share the 8-character code with a friend. Your friend opens the SAME game on Study Games and enters it under Join Friend. Creator plays first; joiner plays second. A new code is generated for each room.

ONLINE ROOM NOTES
- Rooms use PeerJS via a free third-party signaling service and browser-to-browser WebRTC connections. No personal logins needed. The connection service must be reachable from both devices. Restricted school or mobile networks may block it.
- Room codes are temporary and not persistent. Leave the game open until your friend joins. The room shuts down when the creator exits.
- There is no open chat or public lobby. Share codes only with friends you know.
- Internet two-device play was checked with simulated peer connections; it has NOT been verified against the external service on real devices.

INSTALLATION
Replace the current index.html in your GitHub STUDYGAMES4FUN repository with the file in this package and commit changes. After GitHub Pages publishes it, reload Study Games. The website cannot be updated by downloading the file alone.

PRESERVED
Original YouTube music player for Digger Funk and Shape of You, red-screen music, premium code recognition, AI Study Helper, games, daily challenges, and gorilla surprise. Premium game access requirements are unchanged.
