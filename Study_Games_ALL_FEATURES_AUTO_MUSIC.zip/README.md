# Study Games — complete website + red-screen audio auto-start

This `index.html` is the full latest Study Games website, preserving Premium redemption, AI Study Helper, games, intro cutscene, gorilla 12345 surprise, Added Files, and the embedded red-screen song.

## Publish
1. Download `index.html` and replace the existing `index.html` in your GitHub Pages repository.
2. Commit changes.
3. Reopen the page and refresh it to load the new version.

## About red-screen music
The embedded red-screen song now requests audible autoplay immediately and retries as the page finishes loading or becomes active. No separate music button is added.

**Important:** iPhone Safari (and some other browsers) block audible autoplay before a user gesture. A website cannot force its way around this browser restriction. If it is blocked, tapping anywhere on the red background starts the same song. The song plays automatically on devices/browsers that allow it.

This ZIP does not publish anything directly to GitHub. Songs from external publishers require permission to be distributed on a public website.
